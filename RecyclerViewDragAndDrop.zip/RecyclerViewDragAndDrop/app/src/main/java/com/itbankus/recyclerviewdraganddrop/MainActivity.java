package com.itbankus.recyclerviewdraganddrop;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import com.itbankus.recyclerviewdraganddrop.adapter.MyRecyclerViewAdapter;
import com.itbankus.recyclerviewdraganddrop.models.FriendProfile;
import com.itbankus.recyclerviewdraganddrop.utils.MyCustomItemTouchHelper;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class MainActivity extends AppCompatActivity {
    @BindView(R.id.recycler)
    RecyclerView recyclerView;

    public static ItemTouchHelper itemTouchHelper;
    private MyRecyclerViewAdapter adapter;
    private List<FriendProfile> alldata;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        alldata = getFriendData();
        adapter = new MyRecyclerViewAdapter(this, alldata);
        ItemTouchHelper.Callback callback =
                new MyCustomItemTouchHelper(adapter);
        itemTouchHelper = new ItemTouchHelper(callback);
        itemTouchHelper.attachToRecyclerView(null);
        itemTouchHelper.attachToRecyclerView(recyclerView);
        recyclerView.setAdapter(adapter);
    }


    private List<FriendProfile> getFriendData() {
        List<FriendProfile> data = new ArrayList<>();
        data.clear();
        String[] names = {"Aung Pyae Phyo", "Phoe Kyaw", "Tun Tun Min", "Kyaw Min Thu", "Sai Soe San", "Kyaw Ye Aung", "Ko Boe Taw", "Ko Lin Htet", "Aung Htoo Win",
        "Hlaing Aung", "Ko Toe Naing"};
        for (int index = 0; index < names.length; index++) {
            FriendProfile friendProfile = new FriendProfile(names[index]);
            data.add(friendProfile);
        }
        return data;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.refresh_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        alldata.clear();
        alldata.addAll(getFriendData());
        adapter.notifyDataSetChanged();
        return true;
    }
}
