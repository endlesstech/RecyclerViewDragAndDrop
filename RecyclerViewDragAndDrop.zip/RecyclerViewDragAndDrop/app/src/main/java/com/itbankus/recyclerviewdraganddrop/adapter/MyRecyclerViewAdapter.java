package com.itbankus.recyclerviewdraganddrop.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.itbankus.recyclerviewdraganddrop.MainActivity;
import com.itbankus.recyclerviewdraganddrop.R;
import com.itbankus.recyclerviewdraganddrop.models.FriendProfile;
import com.itbankus.recyclerviewdraganddrop.utils.ItemTouchHelperAdapter;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class MyRecyclerViewAdapter extends RecyclerView.Adapter<MyRecyclerViewAdapter.MyRecyclerViewHolder> implements ItemTouchHelperAdapter {
    Context context;
    List<FriendProfile> data;

    public MyRecyclerViewAdapter(Context context, List<FriendProfile> data) {
        this.context = context;
        this.data = data;
    }

    @NonNull
    @Override
    public MyRecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyRecyclerViewHolder(LayoutInflater.from(context).inflate(R.layout.recycler_item, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull final MyRecyclerViewHolder holder, int position) {
        holder.name.setText(data.get(position).getName());
        holder.dragdrop.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (motionEvent.getActionMasked() == MotionEvent.ACTION_DOWN) {
                    MainActivity.itemTouchHelper.startDrag(holder);
                }
                return false;
            }
        });

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(context, "You click position:" + holder.getAdapterPosition(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    @Override
    public void onItemMove(int fromPosition, int toPosition) {
        FriendProfile moveItem = data.get(fromPosition);
        data.remove(fromPosition);
        data.add(toPosition, moveItem);
        notifyItemMoved(fromPosition, toPosition);
    }

    @Override
    public void onItemDismiss(int position) {
        data.remove(position);
        notifyItemRemoved(position);
    }

    public class MyRecyclerViewHolder extends RecyclerView.ViewHolder{
        @BindView(R.id.name)
        TextView name;

        @BindView(R.id.iv_dragdrop)
        ImageView dragdrop;
        public MyRecyclerViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}
